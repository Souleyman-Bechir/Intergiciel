package com.intergiciel.enrollmentservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnrollmentserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnrollmentserviceApplication.class, args);
	}

}
