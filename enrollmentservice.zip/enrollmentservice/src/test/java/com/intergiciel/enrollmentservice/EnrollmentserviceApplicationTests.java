package com.intergiciel.enrollmentservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EnrollmentserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
